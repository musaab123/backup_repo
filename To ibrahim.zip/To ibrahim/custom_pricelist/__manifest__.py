# -*- coding: utf-8 -*-
{
    'name': "presys_custom_pricelist",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
        Manages the Discount in Sale  , Purchase Order and in whole Sale order/Purchase order basis on Fix
        and Percentage wise as well as calculate

        This module also have following separated features.
            -List Price Discount on Invoice, List Price on purchase order, List Price Discount on Sales order
            -Discount on sale order line, Discount on purchase order line, Discount on Invoice line
            -Discount purchase, Discount sale,Discount Invoice, Discount POS, Disount Order,Order Discount, Point of Sale Discount,Discont on pricelist, Fixed Discount, Percentage Discount, Commission, Discount Tax.
            -All in One Discount, All discount, Sales Discount, Purchase Discount,Sales Invoice Discount, Purchase Invoice Discount,Odoo Discount, OpenERP Discount, Sale Order Discount, Purchase order discount, Invoice line Discount,Discount with Taxes, Order line Discount, sale line discount, purchase line discount,Discount on line.Discount Feature, Discount for all

        Salae Team Price List.
        Brand For Broduct
        Branch For Company
        
        Discount Fix Price
        Discount Discount
        discount Formula
    """,

    'author': "Prosys",
    'website': "https://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/16.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['product_brand_inventory', 'product','multi_branch_base'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
